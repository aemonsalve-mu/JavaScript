// Inicializa el mapa con una vista centrada en [51.505, -0.09] y un nivel de zoom de 13
const map = L.map('map').setView([51.505, -0.09], 13);

// Añade la capa de teselado desde OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Agrega varios círculos en el mapa con diferentes coordenadas y radios
L.circle([51.508, -0.11], { color: 'red', radius: 500 }).addTo(map);
L.circle([51.503, -0.08], { color: 'green', radius: 300 }).addTo(map);
L.circle([51.51, -0.1], { color: 'blue', radius: 200 }).addTo(map);