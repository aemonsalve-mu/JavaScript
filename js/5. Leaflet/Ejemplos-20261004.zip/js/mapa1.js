// Inicializa el mapa en el elemento HTML con el id 'map'
// La vista se centra en las coordenadas [51.505, -0.09] con un nivel de zoom de 13
const map = L.map('map').setView([51.505, -0.09], 13);

// Añade una capa de teselado (tiles) de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19, // Define el zoom máximo
  attribution: '&copy; OpenStreetMap contributors' // Atribución requerida por OpenStreetMap
}).addTo(map);