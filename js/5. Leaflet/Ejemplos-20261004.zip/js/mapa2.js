// Inicializa el mapa centrado en una ubicación específica
const map = L.map('map').setView([43.27206, -2.96396], 13);

// Añade la capa de teselado de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Agrega un marcador en las coordenadas [51.505, -0.09]
const marker = L.marker([43.27206, -2.96396]).addTo(map);

// Vincula un pop-up al marcador con un mensaje personalizado
marker.bindPopup('¡Hola! estamos en AsFabrik').openPopup();