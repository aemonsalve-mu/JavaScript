// Inicializa el mapa centrado en el País Vasco para abarcar todos los estadios
const map = L.map('map').setView([43.0, -2.5], 8);

// Añade la capa de teselado de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Información de los estadios: coordenadas, nombre y capacidad
const stadiums = [
  { name: "Mendizorroza", coords: [42.837127910860325, -2.6882390795417885], capacity: 19840 },
  { name: "San Mamés", coords: [43.2641989212274, -2.9493784644394214], capacity: 53289 },
  { name: "Reale Arena", coords: [43.30190934878344, -1.9735438974536839], capacity: 39500 },
  { name: "El Sadar", coords: [42.79704996833328, -1.6370768867133267], capacity: 23516 },
  { name: "Ipurua", coords: [43.181921507336355, -2.4758572732105515], capacity: 8164 }
];

// Función para convertir la capacidad en un radio de círculo
const capacityToRadius = (capacity) => capacity / 100;

// Función para determinar el color del círculo basado en la capacidad
const getColorByCapacity = (capacity) => {
  if (capacity <= 10000) return 'green';
  if (capacity <= 25000) return 'blue';
  return 'red';
};

// Itera sobre cada estadio y crea un círculo con el radio y color basados en su capacidad
stadiums.forEach(stadium => {
  const color = getColorByCapacity(stadium.capacity);
  
  L.circle(stadium.coords, {
    color: color,
    fillColor: color,
    fillOpacity: 0.5,
    radius: capacityToRadius(stadium.capacity)
  })
  .addTo(map)
  .bindPopup(`${stadium.name}<br>Capacidad: ${stadium.capacity}`);
});

// Agrega una leyenda para indicar el significado de cada color
const legend = L.control({ position: 'topleft' });

legend.onAdd = function () {
  const div = L.DomUtil.create('div', 'info legend');
  div.innerHTML += `<h4>Capacidad del Estadio</h4>`;
  div.innerHTML += `<i style="background: green"></i>Verde: 0 - 10000<br>`;
  div.innerHTML += `<i style="background: blue"></i>Azul: 10000 - 25000<br>`;
  div.innerHTML += `<i style="background: red"></i>Rojo: 25000+<br>`;
  return div;
};

legend.addTo(map);