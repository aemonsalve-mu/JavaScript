// Inicializa el mapa en un punto arbitrario antes de centrarlo en la ubicación del usuario
const map = L.map('map').setView([43.2641989212274, -2.9493784644394214], 11);

// Añade la capa de teselado de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Utiliza la API de geolocalización del navegador para centrar el mapa en la ubicación del usuario
map.locate({ setView: true, maxZoom: 16 });

// Evento que se activa cuando se encuentra la ubicación del usuario
map.on('locationfound', (e) => {
  const radius = e.accuracy; // Define el radio de precisión en metros

  // Coloca un marcador en la ubicación actual y muestra el radio de precisión
  L.marker(e.latlng).addTo(map).bindPopup(`Estás a ${radius.toFixed(2)} metros de este punto`).openPopup();
  L.circle(e.latlng, radius).addTo(map); // Añade un círculo alrededor del punto del usuario
});

// Evento que se activa si la geolocalización falla
map.on('locationerror', () => {
  alert('No se pudo encontrar la ubicación.');
});
