// Inicializa el mapa centrado en [51.505, -0.09] con un zoom de 13
const map = L.map('map').setView([42.837127910860325, -2.6882390795417885], 10);

// Añade la capa de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Define una ruta como una serie de coordenadas (latitud y longitud)
const route = [
  [42.837127910860325, -2.6882390795417885],
  [43.2641989212274, -2.9493784644394214],
  [43.30190934878344, -1.9735438974536839],
  [42.79704996833328, -1.6370768867133267]
];

// Dibuja la polilínea en el mapa usando la ruta definida
L.polyline(route, { color: 'blue' }).addTo(map);