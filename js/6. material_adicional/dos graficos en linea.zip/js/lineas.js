
var parseTime = d3.timeParse("%Y-%m-%dT%H:%M:%S");

d3.csv("https://raw.githubusercontent.com/AJM05/Bdata3-Visualizaci-n-datos/main/AENA.csv",function(error,datos){
    if(error) throw error;

    datos.forEach(function(d){
        d.date = parseTime(d.date);
        d.high = +d.high;
        d.low = +d.low;
    })

    datos.sort(function(a,b){
        return new Date(b.date) - new Date(a.date);
    })

    function unpack(datos, columna){
        return datos.map(function(fila){return fila[columna];});
    }

    //console.log(unpack(datos,"date"))

    var serie_high = {
        x : unpack(datos,"date"),
        y: unpack(datos,"high"),
        type: "scatter",
        name:("High"),
        line : {
            color: "#8b61ca"
        }
    }

    var serie_low = {
        x : unpack(datos,"date"),
        y: unpack(datos,"low"),
        type: "scatter",
        name:("Low"),
        line : {
            color: "#07c0e4"
        }
    }

    var layout = {
        title: "Dos lineas",
        xaxis:{
            title: "Unas fechas",
            rangeselector:{buttons:[
                {
                    count: 1,
                    label: "1m",
                    step: "month",
                    stepmode: "backward"
                },
                {
                    count: 6,
                    label: "6m",
                    step: "month",
                    stepmode: "backward"
                },
                {step: "all"}
            ]},
            rangeslider: {range:[d3.min(unpack(datos,"date")),d3.max(unpack(datos,"date"))]},
            type: "date"
        },
        yaxis:{
            title: "Unos euros"
        },
        legend: {
            y:0.75,
            font:{
                size: 12
            }
        },
        annotations:[{
            x: "2020-08-19",
            y:150,
            xref:"x",
            yref: "y",
            text: "Mi cumpleaños"
        }]
    }

    var grafico = [serie_high,serie_low]

    Plotly.newPlot("lineas",grafico,layout)
    Plotly.newPlot("lineas2",grafico,layout)


})