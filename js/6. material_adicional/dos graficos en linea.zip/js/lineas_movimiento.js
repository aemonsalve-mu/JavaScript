
var parseTime = d3.timeParse("%Y-%m-%dT%H:%M:%S");

d3.csv("https://raw.githubusercontent.com/AJM05/Bdata3-Visualizaci-n-datos/main/AENA.csv",function(error,datos){
    if(error) throw error;

    datos.forEach(function(d){
        d.date = parseTime(d.date);
        d.high = +d.high;
        d.low = +d.low;
    })

    datos.sort(function(a,b){
        return new Date(a.date) - new Date(b.date);
    })

    function unpack(datos, columna){
        return datos.map(function(fila){return fila[columna];});
    }
    
    
    var frames = [];
    var x = unpack(datos,"date");
    var y = unpack(datos,"high");
    var x2 = unpack(datos,"date");
    var y2 = unpack(datos,"low");

    const margen_top = d3.max(y) + 20
    const margen_bot = d3.min(y2) -20

    var n = x.length;
    for(var i = 0; i < n; i+=3){
        pos = i/3
        frames[pos] = {data: [{x:[], y:[]}, {x:[], y:[]}]}
        frames[pos].data[1].x = x.slice(0,i+1)
        frames[pos].data[1].y = y.slice(0,i+1)
        frames[pos].data[0].x = x2.slice(0,i+1)
        frames[pos].data[0].y = y2.slice(0,i+1)
    }


    var linea1 = {
        type:"scatter",
        mode: "lines",
        name:"High",
        fill: "tonexty",
        x: frames[5].data[1].x,
        y: frames[5].data[1].y,
        line:{
            color:"#8b61ca"
        }
        
    }

    var linea2 = {
        type:"scatter",
        mode: "lines",
        name:"Low",
        x: frames[5].data[0].x,
        y: frames[5].data[0].y,
        line:{
            color:"#07c0e4"
        }
    }

    var grafico = [linea2,linea1]

    var layout = {
        title: "lineas movimiento",
        xaxis: {
            range:[d3.min(x),d3.max(x)],
            showgrid: true
        },
        yaxis: {
            range:[margen_bot,margen_top],
            showgrid: true
        },
        updatemenus:[{
            x: 0.5,
            y: 0,
            yanchor: "top",
            xanchor:"center",
            showactive: false,
            direction: "left",
            type: "buttons",
            pad: {"t":50,"r":10},
            buttons:[{
                method:"animate",
                args:[null,{
                    fromcurrent: true,
                    transition:{
                        duration:0
                    },
                    frame: {
                        duration: 40,
                        redraw: false
                    }
                }],
                label:"Dale"
            }, {
                method:"animate",
                args:[
                    [null],
                    {
                        mode:"inmediate",
                        transition:{
                            duration:0
                        },
                        frame:{
                            duration:0,
                            redraw: false
                        }
                    }
                ],
                label: "Pause"
            }]
        }]
    }


    Plotly.newPlot("div",grafico,layout).then(function(){
        Plotly.addFrames("div",frames);
    })

})